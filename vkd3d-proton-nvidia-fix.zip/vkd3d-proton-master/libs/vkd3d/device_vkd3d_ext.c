/*
 * * Copyright 2021 NVIDIA Corporation
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301, USA
 */

#define VKD3D_DBG_CHANNEL VKD3D_DBG_CHANNEL_API

#include "vkd3d_private.h"
#include "nvShaderExtnEnums.h"

uint32_t vkd3d_nv_shader_extn_entry_hash(const void *key)
{
    return *(const unsigned int *)key;
}

bool vkd3d_nv_shader_extn_entry_compare(const void *key, const struct hash_map_entry *entry)
{
    const struct vkd3d_nv_shader_extn_entry *extn = (const void*)entry;
    const unsigned int *thread_id = key;
    return *thread_id == extn->thread_id;
}

int vkd3d_nv_shader_init(struct d3d12_device *device)
{
    int rc = pthread_mutex_init(&device->vendor_hacks.nv_shader.mutex, NULL);

    device->vendor_hacks.nv_shader.initialized = false;
    device->vendor_hacks.nv_shader.enabled = false;

    if (rc)
        return rc;

    hash_map_init(&device->vendor_hacks.nv_shader.map,
        vkd3d_nv_shader_extn_entry_hash,
        vkd3d_nv_shader_extn_entry_compare,
        sizeof(struct vkd3d_nv_shader_extn_entry));

    device->vendor_hacks.nv_shader.initialized = true;

    return 0;
}

void vkd3d_nv_shader_cleanup(struct d3d12_device *device)
{
    if (!device->vendor_hacks.nv_shader.initialized)
        return;

    device->vendor_hacks.nv_shader.initialized = false;
    hash_map_free(&device->vendor_hacks.nv_shader.map);
    pthread_mutex_destroy(&device->vendor_hacks.nv_shader.mutex);
}

struct vkd3d_nv_shader_extn d3d12_device_get_nv_shader_extn(struct d3d12_device *device)
{
    struct vkd3d_nv_shader_extn result = { UINT32_MAX, 0 };
    struct vkd3d_nv_shader_extn_entry *entry;
    unsigned int key;
    int rc;

    if (!device->vendor_hacks.nv_shader.initialized || !device->vendor_hacks.nv_shader.enabled)
        return result;

    key = vkd3d_get_current_thread_id();

    if ((rc = pthread_mutex_lock(&device->vendor_hacks.nv_shader.mutex)))
    {
        ERR("Failed to lock mutex, rc %d.\n", rc);
        return result;
    }

    entry = (void*)hash_map_find(&device->vendor_hacks.nv_shader.map, &key);

    if (!entry || entry->extn.uav_slot == UINT32_MAX)
    {
        key = 0;
        entry = (void*)hash_map_find(&device->vendor_hacks.nv_shader.map, &key);
    }

    if (entry)
        result = entry->extn;

    if ((rc = pthread_mutex_unlock(&device->vendor_hacks.nv_shader.mutex)))
        ERR("Failed to unlock mutex, rc %d.\n", rc);

    return result;
}

static inline struct d3d12_device *d3d12_device_from_ID3D12DeviceExt(d3d12_device_vkd3d_ext_iface *iface)
{
    return CONTAINING_RECORD(iface, struct d3d12_device, ID3D12DeviceExt_iface);
}

ULONG STDMETHODCALLTYPE d3d12_device_vkd3d_ext_AddRef(d3d12_device_vkd3d_ext_iface *iface)
{
    struct d3d12_device *device = d3d12_device_from_ID3D12DeviceExt(iface);
    return d3d12_device_add_ref(device);
}

static ULONG STDMETHODCALLTYPE d3d12_device_vkd3d_ext_Release(d3d12_device_vkd3d_ext_iface *iface)
{
    struct d3d12_device *device = d3d12_device_from_ID3D12DeviceExt(iface);
    return d3d12_device_release(device);
}

extern HRESULT STDMETHODCALLTYPE d3d12_device_QueryInterface(d3d12_device_iface *iface,
        REFIID riid, void **object);

static HRESULT STDMETHODCALLTYPE d3d12_device_vkd3d_ext_QueryInterface(d3d12_device_vkd3d_ext_iface *iface,
        REFIID iid, void **out)
{
    struct d3d12_device *device = d3d12_device_from_ID3D12DeviceExt(iface);
    TRACE("iface %p, iid %s, out %p.\n", iface, debugstr_guid(iid), out);
    return d3d12_device_QueryInterface(&device->ID3D12Device_iface, iid, out);
}

static HRESULT STDMETHODCALLTYPE d3d12_device_vkd3d_ext_GetVulkanHandles(d3d12_device_vkd3d_ext_iface *iface, VkInstance *vk_instance, VkPhysicalDevice *vk_physical_device, VkDevice *vk_device)
{
    struct d3d12_device *device = d3d12_device_from_ID3D12DeviceExt(iface);
    TRACE("iface %p, vk_instance %p, vk_physical_device %p, vk_device %p\n", iface, vk_instance, vk_physical_device, vk_device);
    if (!vk_device || !vk_instance || !vk_physical_device)
        return E_INVALIDARG;
        
    *vk_instance = device->vkd3d_instance->vk_instance;
    *vk_physical_device = device->vk_physical_device;
    *vk_device = device->vk_device;
    return S_OK;
}

static BOOL STDMETHODCALLTYPE d3d12_device_vkd3d_ext_GetExtensionSupport(d3d12_device_vkd3d_ext_iface *iface, D3D12_VK_EXTENSION extension)
{
    const struct d3d12_device *device = d3d12_device_from_ID3D12DeviceExt(iface);
    bool ret_val = false;
    
    TRACE("iface %p, extension %u\n", iface, extension);
    switch (extension)
    {
        case D3D12_VK_EXT_OPACITY_MICROMAP:
            ret_val = device->device_info.supports_opacity_micromap;
            break;
        case D3D12_VK_NVX_BINARY_IMPORT:
            ret_val = device->vk_info.NVX_binary_import;
            break;
        case D3D12_VK_NVX_IMAGE_VIEW_HANDLE:
            ret_val = device->vk_info.NVX_image_view_handle;
            if (ret_val && d3d12_device_use_descriptor_heap(device))
                ret_val = device->vk_procs.vkGetDeviceCombinedImageSamplerIndexNVX != NULL;
            break;
        case D3D12_VK_NV_LOW_LATENCY_2:
            ret_val = device->vk_info.NV_low_latency2;
            break;
        case D3D12_VK_NV_OPTICAL_FLOW:
            ret_val = device->vk_info.NV_optical_flow;
            break;
        default:
            WARN("Invalid extension %x.\n", extension);
    }
    
    return ret_val;
}

static HRESULT d3d12_device_vkd3d_ext_create_cubin_compute_shader(struct d3d12_device *device,
       const void *cubin_data, UINT32 cubin_size, UINT32 block_x, UINT32 block_y, UINT32 block_z,
       const char *shader_name, bool use_64bit_texturing, UINT32 flags, D3D12_CUBIN_DATA_HANDLE **out_handle)
{
    VkCuFunctionCreateInfoNVX functionCreateInfo = { VK_STRUCTURE_TYPE_CU_FUNCTION_CREATE_INFO_NVX };
    VkCuModuleCreateInfoNVX moduleCreateInfo = { VK_STRUCTURE_TYPE_CU_MODULE_CREATE_INFO_NVX };
    VkCuModuleTexturingModeCreateInfoNVX moduleTexturingModeCreateInfo;
    const struct vkd3d_vk_device_procs *vk_procs;
    D3D12_CUBIN_DATA_HANDLE *handle;
    VkDevice vk_device;
    VkResult vr;

    if (!cubin_data || !cubin_size || !shader_name || flags)
        return E_INVALIDARG;

    vk_procs = &device->vk_procs;

    if (use_64bit_texturing)
    {
        if (!device->vk_info.supports_cubin_64bit || !vk_procs->vkGetImageViewHandle64NVX)
            return E_NOTIMPL;

        moduleTexturingModeCreateInfo.sType = VK_STRUCTURE_TYPE_CU_MODULE_TEXTURING_MODE_CREATE_INFO_NVX;
        moduleTexturingModeCreateInfo.pNext = NULL;
        moduleTexturingModeCreateInfo.use64bitTexturing = VK_TRUE;
        moduleCreateInfo.pNext = &moduleTexturingModeCreateInfo;
    }

    vk_device = device->vk_device;
    handle = vkd3d_calloc(1, sizeof(D3D12_CUBIN_DATA_HANDLE));
    if (!handle)
        return E_OUTOFMEMORY;

    handle->blockX = block_x;
    handle->blockY = block_y;
    handle->blockZ = block_z;

    moduleCreateInfo.pData = cubin_data;
    moduleCreateInfo.dataSize = cubin_size;
    if ((vr = VK_CALL(vkCreateCuModuleNVX(vk_device, &moduleCreateInfo, NULL, &handle->vkCuModule))) < 0)
    {
        ERR("Failed to create cubin shader, vr %d.\n", vr);
        vkd3d_free(handle);
        return hresult_from_vk_result(vr);
    }

    functionCreateInfo.module = handle->vkCuModule;
    functionCreateInfo.pName = shader_name;

    if ((vr = VK_CALL(vkCreateCuFunctionNVX(vk_device, &functionCreateInfo, NULL, &handle->vkCuFunction))) < 0)
    {
        ERR("Failed to create cubin function module, vr %d.\n", vr);
        VK_CALL(vkDestroyCuModuleNVX(vk_device, handle->vkCuModule, NULL));
        vkd3d_free(handle);
        return hresult_from_vk_result(vr);
    }

    *out_handle = handle;
    return S_OK;
}

static HRESULT STDMETHODCALLTYPE d3d12_device_vkd3d_ext_CreateCubinComputeShaderWithName(d3d12_device_vkd3d_ext_iface *iface, const void *cubin_data,
       UINT32 cubin_size, UINT32 block_x, UINT32 block_y, UINT32 block_z, const char *shader_name, D3D12_CUBIN_DATA_HANDLE **out_handle)
{
    TRACE("iface %p, cubin_data %p, cubin_size %"PRIu32", block_x %"PRIu32", block_y %"PRIu32", block_z %"PRIu32", shader_name %s\n",
            iface, cubin_data, cubin_size, block_x, block_y, block_z, shader_name);

    return d3d12_device_vkd3d_ext_create_cubin_compute_shader(d3d12_device_from_ID3D12DeviceExt(iface),
            cubin_data, cubin_size, block_x, block_y, block_z,
            shader_name, false, 0, out_handle);
}

static HRESULT STDMETHODCALLTYPE d3d12_device_vkd3d_ext_DestroyCubinComputeShader(d3d12_device_vkd3d_ext_iface *iface, D3D12_CUBIN_DATA_HANDLE *handle)
{   
    const struct vkd3d_vk_device_procs *vk_procs;
    struct d3d12_device *device;
    VkDevice vk_device;

    TRACE("iface %p, handle %p\n", iface, handle);
    if (!iface || !handle)
        return E_INVALIDARG;
    
    device = d3d12_device_from_ID3D12DeviceExt(iface);
    vk_device = device->vk_device;
    vk_procs = &device->vk_procs;

    VK_CALL(vkDestroyCuFunctionNVX(vk_device, handle->vkCuFunction, NULL));
    VK_CALL(vkDestroyCuModuleNVX(vk_device, handle->vkCuModule, NULL));
    vkd3d_free(handle);
    return S_OK;
}

uint32_t d3d12_device_find_shader_visible_descriptor_heap_offset(
        struct d3d12_device *device, vkd3d_cpu_descriptor_va_t va, D3D12_DESCRIPTOR_HEAP_TYPE type)
{
    size_t offset = vkd3d_va_map_query_descriptor_heap_offset(&device->memory_allocator.va_map, va, type);
    if (offset == SIZE_MAX)
        return UINT32_MAX;

    if (type == D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV)
    {
        offset += device->bindless_state.heap.redzone_size;
        offset /= device->device_info.descriptor_heap_properties.imageDescriptorSize;
    }
    else
    {
        offset /= device->device_info.descriptor_heap_properties.samplerDescriptorSize;
    }

    return offset;
}

static HRESULT STDMETHODCALLTYPE d3d12_device_vkd3d_ext_GetCudaTextureObject(d3d12_device_vkd3d_ext_iface *iface, D3D12_CPU_DESCRIPTOR_HANDLE srv_handle,
       D3D12_CPU_DESCRIPTOR_HANDLE sampler_handle, UINT32 *cuda_texture_handle)
{
    VkImageViewHandleInfoNVX imageViewHandleInfo = { VK_STRUCTURE_TYPE_IMAGE_VIEW_HANDLE_INFO_NVX };
    const struct vkd3d_vk_device_procs *vk_procs;
    struct d3d12_desc_split sampler_desc;
    struct d3d12_desc_split srv_desc;
    struct d3d12_device *device;
    uint32_t sampler_index;
    uint32_t image_index;

    TRACE("iface %p, srv_handle %zu, sampler_handle %zu, cuda_texture_handle %p.\n",
            iface, (size_t)srv_handle.ptr, (size_t)sampler_handle.ptr, cuda_texture_handle);

    if (!cuda_texture_handle)
       return E_INVALIDARG;

    device = d3d12_device_from_ID3D12DeviceExt(iface);
    vk_procs = &device->vk_procs;

    if (d3d12_device_use_descriptor_heap(device))
    {
        image_index = d3d12_device_find_shader_visible_descriptor_heap_offset(device, srv_handle.ptr,
                D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV);
        sampler_index = d3d12_device_find_shader_visible_descriptor_heap_offset(device, sampler_handle.ptr,
                D3D12_DESCRIPTOR_HEAP_TYPE_SAMPLER);

        if (image_index == UINT32_MAX || sampler_index == UINT32_MAX)
        {
            FIXME("Could not find heap index. CPU handles must point to SHADER_VISIBLE heaps to have any meaning.\n");
            return E_INVALIDARG;
        }

        *cuda_texture_handle = VK_CALL(vkGetDeviceCombinedImageSamplerIndexNVX(device->vk_device,
                image_index, sampler_index));
    }
    else
    {
        srv_desc = d3d12_desc_decode_va(srv_handle.ptr);
        sampler_desc = d3d12_desc_decode_va(sampler_handle.ptr);

        /* If image flag is not set, descriptor cannot be used as a CudaTexture */
        if (!(srv_desc.view->info.flags & VKD3D_DESCRIPTOR_FLAG_IMAGE_VIEW))
            return E_INVALIDARG;

        imageViewHandleInfo.imageView = srv_desc.view->info.image.view->vk_image_view;
        imageViewHandleInfo.sampler = sampler_desc.view->info.image.view->vk_sampler;
        imageViewHandleInfo.descriptorType = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER;

        *cuda_texture_handle = VK_CALL(vkGetImageViewHandleNVX(device->vk_device, &imageViewHandleInfo));
    }

    return S_OK;
}

static HRESULT STDMETHODCALLTYPE d3d12_device_vkd3d_ext_GetCudaSurfaceObject(d3d12_device_vkd3d_ext_iface *iface, D3D12_CPU_DESCRIPTOR_HANDLE uav_handle, 
        UINT32 *cuda_surface_handle)
{
    VkImageViewHandleInfoNVX imageViewHandleInfo = { VK_STRUCTURE_TYPE_IMAGE_VIEW_HANDLE_INFO_NVX };
    const struct vkd3d_vk_device_procs *vk_procs;
    struct d3d12_desc_split uav_desc;
    struct d3d12_device *device;
    uint32_t image_index;

    TRACE("iface %p, uav_handle %zu, cuda_surface_handle %p.\n", iface, (size_t)uav_handle.ptr, cuda_surface_handle);
    if (!cuda_surface_handle)
        return E_INVALIDARG;

    device = d3d12_device_from_ID3D12DeviceExt(iface);
    vk_procs = &device->vk_procs;

    if (d3d12_device_use_descriptor_heap(device))
    {
        image_index = d3d12_device_find_shader_visible_descriptor_heap_offset(device,
                uav_handle.ptr, D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV);

        if (image_index == UINT32_MAX)
        {
            FIXME("Could not find heap index. CPU handles must point to SHADER_VISIBLE heaps to have any meaning.\n");
            return E_INVALIDARG;
        }

        *cuda_surface_handle = VK_CALL(vkGetDeviceCombinedImageSamplerIndexNVX(device->vk_device,
                image_index, 0));
    }
    else
    {
        uav_desc = d3d12_desc_decode_va(uav_handle.ptr);

        /* If image flag is not set, descriptor cannot be used as a CudaSurface */
        if (!(uav_desc.view->info.flags & VKD3D_DESCRIPTOR_FLAG_IMAGE_VIEW))
            return E_INVALIDARG;

        imageViewHandleInfo.imageView = uav_desc.view->info.image.view->vk_image_view;
        imageViewHandleInfo.descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_IMAGE;

        *cuda_surface_handle = VK_CALL(vkGetImageViewHandleNVX(device->vk_device, &imageViewHandleInfo));
    }

    return S_OK; 
}

extern VKD3D_THREAD_LOCAL struct D3D12_UAV_INFO *d3d12_uav_info;

static HRESULT STDMETHODCALLTYPE d3d12_device_vkd3d_ext_CaptureUAVInfo(d3d12_device_vkd3d_ext_iface *iface, D3D12_UAV_INFO *uav_info)
{
    if (!uav_info)
        return E_INVALIDARG;

    TRACE("iface %p, uav_info %p.\n", iface, uav_info);
    
    /* CaptureUAVInfo() supposed to capture the information from the next CreateUnorderedAccess() on the same thread. 
       We use d3d12_uav_info pointer to update the information in CreateUnorderedAccess() */
    d3d12_uav_info = uav_info;
    return S_OK;
}

static HRESULT STDMETHODCALLTYPE d3d12_device_vkd3d_ext_CreateResourceFromBorrowedHandle(d3d12_device_vkd3d_ext_iface *iface,
       const D3D12_RESOURCE_DESC1 *desc, UINT64 vk_handle, ID3D12Resource **ppResource)
{
    struct d3d12_device *device = d3d12_device_from_ID3D12DeviceExt(iface);
    struct d3d12_resource *object;
    HRESULT hr = d3d12_resource_create_borrowed(device, desc, vk_handle, &object);
    if (FAILED(hr))
        return hr;

    *ppResource = (ID3D12Resource *)&object->ID3D12Resource_iface;
    return S_OK;
}

static HRESULT STDMETHODCALLTYPE d3d12_device_vkd3d_ext_GetVulkanQueueInfoEx(d3d12_device_vkd3d_ext_iface *iface,
       ID3D12CommandQueue *queue, VkQueue *vk_queue, UINT32 *vk_queue_index, UINT32 *vk_queue_flags, UINT32 *vk_queue_family)
{
    TRACE("iface %p, queue %p, vk_queue %p, vk_queue_index %p, vk_queue_flags %p vk_queue_family %p.\n",
            iface, queue, vk_queue, vk_queue_index, vk_queue_flags, vk_queue_family);

    if (FAILED(ID3D12CommandQueue_QueryInterface(queue, &IID_ID3D12ExtDummyInterface, (void **)&queue)))
    {
        ERR("no ID3D12ExtDummyInterface.\n");
        return E_FAIL;
    }
    *vk_queue = vkd3d_lock_vk_queue(queue);
    vkd3d_unlock_vk_queue(queue);

    *vk_queue_index = vkd3d_get_vk_queue_index(queue);
    *vk_queue_flags = vkd3d_get_vk_queue_flags(queue);
    *vk_queue_family = vkd3d_get_vk_queue_family_index(queue);
    ID3D12CommandQueue_Release(queue);
    return S_OK;
}

static BOOL STDMETHODCALLTYPE d3d12_device_vkd3d_ext_SetCreatePipelineStateFlagsNVAPI(d3d12_device_vkd3d_ext_iface *iface,
        D3D12_VK_EXT_PIPELINE_CREATION_STATE_FLAG pipeline_state_flags)
{
    struct d3d12_device *device = d3d12_device_from_ID3D12DeviceExt(iface);
    VKD3D_UNUSED VkPipelineCreateFlags ray_tracing_pipeline_create_flags;
    bool enable_opacity_micromap;

    TRACE("iface %p, pipeline_state_flags %d.\n", iface, pipeline_state_flags);

    enable_opacity_micromap = (pipeline_state_flags & D3D12_VK_EXT_PIPELINE_CREATION_STATE_FLAGS_ENABLE_OMM_SUPPORT) != 0;

    if (enable_opacity_micromap)
    {
        if (!device->device_info.supports_opacity_micromap)
        {
            ERR("Opacity micromap is not supported.\n");
            return FALSE;
        }

        ray_tracing_pipeline_create_flags = vkd3d_atomic_uint32_or(&device->vendor_hacks.global_ray_tracing_pipeline_create_flags,
                VK_PIPELINE_CREATE_RAY_TRACING_OPACITY_MICROMAP_BIT_KHR, vkd3d_memory_order_relaxed) |
                VK_PIPELINE_CREATE_RAY_TRACING_OPACITY_MICROMAP_BIT_KHR;

        /* Set force_ray_query_omm to true the first time ENABLE_OMM_SUPPORT is set.
         * This causes any RayQuery shader with SM < 6.9 to consult the OMM.
         * 1. NVAPI has no way to opt into the OMM on the RayQuery.
         * 2. Treated as a sticky bit to deal with possible race conditions where the bit is
         *    set after a PSO using RayQuery has already been created.
         * 3. There is a small possibility that a PSO could be created with a RayQuery before
         *    ENABLE_OMM_SUPPORT is set; in that window the RayQuery will not consult the OMM. */
        vkd3d_atomic_uint32_or(&device->vendor_hacks.force_ray_query_omm, 1u, vkd3d_memory_order_relaxed);
    }
    else
    {
        ray_tracing_pipeline_create_flags = vkd3d_atomic_uint32_and(&device->vendor_hacks.global_ray_tracing_pipeline_create_flags,
                ~VK_PIPELINE_CREATE_RAY_TRACING_OPACITY_MICROMAP_BIT_KHR, vkd3d_memory_order_relaxed) &
                ~VK_PIPELINE_CREATE_RAY_TRACING_OPACITY_MICROMAP_BIT_KHR;
    }

    TRACE("flags #%x.\n", ray_tracing_pipeline_create_flags);

    return TRUE;
}

static BOOL STDMETHODCALLTYPE d3d12_device_vkd3d_ext_SupportsCubin64bit(d3d12_device_vkd3d_ext_iface *iface)
{
    struct d3d12_device *device = d3d12_device_from_ID3D12DeviceExt(iface);
    const struct vkd3d_vk_device_procs *vk_procs = &device->vk_procs;

    TRACE("iface %p.\n", iface);

    return device->vk_info.supports_cubin_64bit && vk_procs->vkGetImageViewHandle64NVX;
}

static HRESULT STDMETHODCALLTYPE d3d12_device_vkd3d_ext_CreateCubinComputeShaderExV2(d3d12_device_vkd3d_ext_iface *iface,
       D3D12_CREATE_CUBIN_SHADER_PARAMS *params)
{
    TRACE("iface %p, cubin_data %p, cubin_size %"PRIu32", block_x %"PRIu32", block_y %"PRIu32", block_z %"PRIu32", shader_name %s, flags %"PRIx32"\n",
            iface, params->pCubin, params->size, params->blockX, params->blockY, params->blockZ, params->pShaderName, params->flags);
    
    if (params->pNext)
    {
        FIXME("pNext not supported.\n");
        params->pNext = NULL;
    }

    return d3d12_device_vkd3d_ext_create_cubin_compute_shader(d3d12_device_from_ID3D12DeviceExt(iface),
            params->pCubin, params->size, params->blockX, params->blockY, params->blockZ,
            params->pShaderName, true, params->flags, &params->hShader);
}

static HRESULT STDMETHODCALLTYPE d3d12_device_vkd3d_ext_GetCudaMergedTextureSamplerObject(d3d12_device_vkd3d_ext_iface *iface,
       D3D12_GET_CUDA_MERGED_TEXTURE_SAMPLER_OBJECT_PARAMS *params)
{
    VkImageViewHandleInfoNVX imageViewHandleInfo = { VK_STRUCTURE_TYPE_IMAGE_VIEW_HANDLE_INFO_NVX };
    struct d3d12_device *device = d3d12_device_from_ID3D12DeviceExt(iface);
    const struct vkd3d_vk_device_procs *vk_procs = &device->vk_procs;
    struct d3d12_desc_split sampler_desc, texture_desc;
    uint32_t image_index = 0, sampler_index = 0;

    TRACE("iface %p, tex_desc %zu, smp_desc %zu.\n",
            iface, (size_t)params->texDesc, (size_t)params->smpDesc);

    if (!device->vk_info.supports_cubin_64bit)
        return E_NOTIMPL;

    if (params->pNext)
    {
        FIXME("pNext not supported.\n");
        params->pNext = NULL;
    }

    if (d3d12_device_use_descriptor_heap(device))
    {
        if (params->texDesc)
        {
            image_index = d3d12_device_find_shader_visible_descriptor_heap_offset(device, params->texDesc,
                D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV);
        }

        if (params->smpDesc)
        {
            sampler_index = d3d12_device_find_shader_visible_descriptor_heap_offset(device, params->smpDesc,
                D3D12_DESCRIPTOR_HEAP_TYPE_SAMPLER);
        }

        if (image_index == UINT32_MAX || sampler_index == UINT32_MAX)
        {
            FIXME("Could not find heap index. CPU handles must point to SHADER_VISIBLE heaps to have any meaning.\n");
            return E_INVALIDARG;
        }

        params->textureHandle = VK_CALL(vkGetDeviceCombinedImageSamplerIndexNVX(
                device->vk_device, image_index, sampler_index));
        return S_OK;
    }
    else
    {
        if (!vk_procs->vkGetImageViewHandle64NVX)
            return E_NOTIMPL;

        texture_desc = d3d12_desc_decode_va(params->texDesc);

        if (!(texture_desc.view->info.flags & VKD3D_DESCRIPTOR_FLAG_IMAGE_VIEW))
            return E_INVALIDARG;

        imageViewHandleInfo.imageView = texture_desc.view->info.image.view->vk_image_view;

        if (params->smpDesc)
        {
            sampler_desc = d3d12_desc_decode_va(params->smpDesc);
            imageViewHandleInfo.sampler = sampler_desc.view->info.image.view->vk_sampler;
            imageViewHandleInfo.descriptorType = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER;
        }
        else
        {
            imageViewHandleInfo.descriptorType = VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE;
        }

        params->textureHandle = VK_CALL(vkGetImageViewHandle64NVX(device->vk_device, &imageViewHandleInfo));
    }

    return S_OK;
}

static HRESULT STDMETHODCALLTYPE d3d12_device_vkd3d_ext_GetCudaIndependentDescriptorObject(d3d12_device_vkd3d_ext_iface *iface,
       D3D12_GET_CUDA_INDEPENDENT_DESCRIPTOR_OBJECT_PARAMS *params)
{
    VkImageViewHandleInfoNVX imageViewHandleInfo = { VK_STRUCTURE_TYPE_IMAGE_VIEW_HANDLE_INFO_NVX };
    struct d3d12_device *device = d3d12_device_from_ID3D12DeviceExt(iface);
    const struct vkd3d_vk_device_procs *vk_procs = &device->vk_procs;
    struct d3d12_desc_split desc;
    uint32_t image_index;

    TRACE("iface %p, desc %zu, type %d.\n",
            iface, (size_t)params->desc, params->type);

    if (!device->vk_info.supports_cubin_64bit || !vk_procs->vkGetImageViewHandle64NVX)
        return E_NOTIMPL;
    
    if (params->pNext)
    {
        FIXME("pNext not supported.\n");
        params->pNext = NULL;
    }

    if (d3d12_device_use_descriptor_heap(device))
    {
        if (params->type != D3D12_GET_CUDA_INDEPENDENT_DESCRIPTOR_OBJECT_SURFACE &&
            params->type != D3D12_GET_CUDA_INDEPENDENT_DESCRIPTOR_OBJECT_TEXTURE)
        {
            ERR("Unsupported object type %d\n", params->type);
            return E_INVALIDARG;
        }

        image_index = d3d12_device_find_shader_visible_descriptor_heap_offset(device, params->desc,
                D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV);

        if (image_index == UINT32_MAX)
        {
            FIXME("Could not find heap index. CPU handles must point to SHADER_VISIBLE heaps to have any meaning.\n");
            return E_INVALIDARG;
        }

        params->handle = VK_CALL(vkGetDeviceCombinedImageSamplerIndexNVX(device->vk_device,
                image_index, 0));
    }
    else
    {
        if (!vk_procs->vkGetImageViewHandle64NVX)
            return E_NOTIMPL;

        desc = d3d12_desc_decode_va(params->desc);

        if (!(desc.view->info.flags & VKD3D_DESCRIPTOR_FLAG_IMAGE_VIEW))
            return E_INVALIDARG;

        imageViewHandleInfo.imageView = desc.view->info.image.view->vk_image_view;

        switch (params->type)
        {
            case D3D12_GET_CUDA_INDEPENDENT_DESCRIPTOR_OBJECT_SURFACE:
                imageViewHandleInfo.descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_IMAGE;
                break;
            case D3D12_GET_CUDA_INDEPENDENT_DESCRIPTOR_OBJECT_TEXTURE:
                imageViewHandleInfo.descriptorType = VK_DESCRIPTOR_TYPE_SAMPLED_IMAGE;
                break;
            case D3D12_GET_CUDA_INDEPENDENT_DESCRIPTOR_OBJECT_SAMPLER:
                FIXME("SAMPLER object type not supported.\n");
                return E_FAIL;
            default:
                ERR("Unsupported object type %d\n", params->type);
                return E_INVALIDARG;
        }

        params->handle = VK_CALL(vkGetImageViewHandle64NVX(device->vk_device, &imageViewHandleInfo));
    }

    return S_OK;
}

static BOOL STDMETHODCALLTYPE d3d12_device_vkd3d_ext_SupportsAGSExtension(
        d3d12_device_vkd3d_ext_iface *iface, D3D12_AGS_EXTENSION agsExtension)
{
    struct d3d12_device *device = d3d12_device_from_ID3D12DeviceExt(iface);
    TRACE("iface %p, agsExtension %u\n", iface, agsExtension);

    switch (agsExtension)
    {
        case D3D12_AGS_EXTENSION_INTRINSICS_19:
            /* DrawIndex and AtomicU64. For Crimson Desert. */
            return true;

        case D3D12_AGS_EXTENSION_WMMA_FP8_NATIVE:
            return device->device_info.shader_float8_features.shaderFloat8CooperativeMatrix == VK_TRUE;

        case D3D12_AGS_EXTENSION_WMMA_FP8:
            if (!device->device_info.cooperative_matrix_features.cooperativeMatrix)
                return false;

#ifndef VKD3D_ENABLE_EXTENDED_EMULATION
            if (!device->device_info.shader_float8_features.shaderFloat8CooperativeMatrix)
                return false;
#endif
            return true;

        default:
            /* Most of these are trivial if need be, but don't do that work unless needed. */
            return false;
    }
}

static HRESULT STDMETHODCALLTYPE d3d12_device_vkd3d_ext_SetAGSUAVSlot(d3d12_device_vkd3d_ext_iface *iface, UINT uavSlot)
{
    /* Possible to implement, just goofy. */
    FIXME("iface %p, uavSlot %u stub!\n", iface, uavSlot);
    return E_NOTIMPL;
}

static BOOL STDMETHODCALLTYPE d3d12_device_vkd3d_ext_IsNvShaderExtnOpCodeSupported(d3d12_device_vkd3d_ext_iface *iface,
        UINT32 op_code)
{
    struct d3d12_device *device = d3d12_device_from_ID3D12DeviceExt(iface);
    TRACE("iface %p, op_code %"PRIu32".\n", iface, op_code);

    if (!device->vendor_hacks.nv_shader.initialized)
        return FALSE;

    switch (op_code)
    {
        case NV_EXTN_OP_HIT_OBJECT_TRACE_RAY:
        case NV_EXTN_OP_HIT_OBJECT_MAKE_HIT:
        case NV_EXTN_OP_HIT_OBJECT_MAKE_HIT_WITH_RECORD_INDEX:
        case NV_EXTN_OP_HIT_OBJECT_MAKE_MISS:
        case NV_EXTN_OP_HIT_OBJECT_REORDER_THREAD:
        case NV_EXTN_OP_HIT_OBJECT_INVOKE:
        case NV_EXTN_OP_HIT_OBJECT_IS_MISS:
        case NV_EXTN_OP_HIT_OBJECT_GET_INSTANCE_ID:
        case NV_EXTN_OP_HIT_OBJECT_GET_INSTANCE_INDEX:
        case NV_EXTN_OP_HIT_OBJECT_GET_PRIMITIVE_INDEX:
        case NV_EXTN_OP_HIT_OBJECT_GET_GEOMETRY_INDEX:
        case NV_EXTN_OP_HIT_OBJECT_GET_HIT_KIND:
        case NV_EXTN_OP_HIT_OBJECT_GET_RAY_DESC:
        case NV_EXTN_OP_HIT_OBJECT_GET_ATTRIBUTES:
        case NV_EXTN_OP_HIT_OBJECT_GET_SHADER_TABLE_INDEX:
        case NV_EXTN_OP_HIT_OBJECT_LOAD_LOCAL_ROOT_TABLE_CONSTANT:
        case NV_EXTN_OP_HIT_OBJECT_IS_HIT:
        case NV_EXTN_OP_HIT_OBJECT_IS_NOP:
        case NV_EXTN_OP_HIT_OBJECT_MAKE_NOP:
            return device->device_info.ray_tracing_invocation_reorder_features_nv.rayTracingInvocationReorder ? TRUE : FALSE;
        default:
            return FALSE;
    }
}

static HRESULT STDMETHODCALLTYPE d3d12_device_vkd3d_ext_SetNvShaderExtnSlotSpace(d3d12_device_vkd3d_ext_iface *iface,
        UINT32 uav_slot, UINT32 uav_space, BOOL local_thread)
{
    struct d3d12_device *device = d3d12_device_from_ID3D12DeviceExt(iface);
    unsigned int key = local_thread ? vkd3d_get_current_thread_id() : 0;
    struct vkd3d_nv_shader_extn extn = { uav_slot, uav_space };
    struct vkd3d_nv_shader_extn_entry e, *entry;
    int rc;

    TRACE("iface %p, uav_slot %"PRIu32", uav_space %"PRIu32", local_thread %i.\n", iface, uav_slot, uav_space, local_thread);

    if (!device->vendor_hacks.nv_shader.initialized)
        return E_FAIL;

    device->vendor_hacks.nv_shader.enabled = true;

    if ((rc = pthread_mutex_lock(&device->vendor_hacks.nv_shader.mutex)))
    {
        ERR("Failed to lock mutex, rc %d.\n", rc);
        return E_FAIL;
    }

    entry = (void*)hash_map_find(&device->vendor_hacks.nv_shader.map, &key);

    if (entry)
    {
        entry->extn = extn;

        if ((rc = pthread_mutex_unlock(&device->vendor_hacks.nv_shader.mutex)))
        {
            ERR("Failed to unlock mutex, rc %d.\n", rc);
            return E_FAIL;
        }

        return S_OK;
    }

    e.thread_id = key;
    entry = (void*)hash_map_insert(&device->vendor_hacks.nv_shader.map, &key, &e.entry);
    entry->extn = extn;

    if ((rc = pthread_mutex_unlock(&device->vendor_hacks.nv_shader.mutex)))
    {
        ERR("Failed to unlock mutex, rc %d.\n", rc);
        return E_FAIL;
    }

    return S_OK;
}

CONST_VTBL struct ID3D12DeviceExt5Vtbl d3d12_device_vkd3d_ext_vtbl =
{
    /* IUnknown methods */
    d3d12_device_vkd3d_ext_QueryInterface,
    d3d12_device_vkd3d_ext_AddRef,
    d3d12_device_vkd3d_ext_Release,

    /* ID3D12DeviceExt methods */
    d3d12_device_vkd3d_ext_GetVulkanHandles,
    d3d12_device_vkd3d_ext_GetExtensionSupport,
    d3d12_device_vkd3d_ext_CreateCubinComputeShaderWithName,
    d3d12_device_vkd3d_ext_DestroyCubinComputeShader,
    d3d12_device_vkd3d_ext_GetCudaTextureObject,
    d3d12_device_vkd3d_ext_GetCudaSurfaceObject,
    d3d12_device_vkd3d_ext_CaptureUAVInfo,

    /* ID3D12DeviceExt1 methods */
    d3d12_device_vkd3d_ext_CreateResourceFromBorrowedHandle,
    d3d12_device_vkd3d_ext_GetVulkanQueueInfoEx,

    /* ID3D12DeviceExt2 methods */
    d3d12_device_vkd3d_ext_SupportsCubin64bit,
    d3d12_device_vkd3d_ext_CreateCubinComputeShaderExV2,
    d3d12_device_vkd3d_ext_GetCudaMergedTextureSamplerObject,
    d3d12_device_vkd3d_ext_GetCudaIndependentDescriptorObject,

    /* ID3D12DeviceExt3 methods */
    d3d12_device_vkd3d_ext_SupportsAGSExtension,
    d3d12_device_vkd3d_ext_SetAGSUAVSlot,

    /* ID3D12DeviceExt4 methods */
    d3d12_device_vkd3d_ext_IsNvShaderExtnOpCodeSupported,
    d3d12_device_vkd3d_ext_SetNvShaderExtnSlotSpace,

    /* ID3D12DeviceExt5 methods */
    d3d12_device_vkd3d_ext_SetCreatePipelineStateFlagsNVAPI,
};

static inline struct d3d12_device *d3d12_device_from_ID3D12DXVKInteropDevice(d3d12_dxvk_interop_device_iface *iface)
{
    return CONTAINING_RECORD(iface, struct d3d12_device, ID3D12DXVKInteropDevice_iface);
}

ULONG STDMETHODCALLTYPE d3d12_dxvk_interop_device_AddRef(d3d12_dxvk_interop_device_iface *iface)
{
    struct d3d12_device *device = d3d12_device_from_ID3D12DXVKInteropDevice(iface);
    return d3d12_device_add_ref(device);
}

static ULONG STDMETHODCALLTYPE d3d12_dxvk_interop_device_Release(d3d12_dxvk_interop_device_iface *iface)
{
    struct d3d12_device *device = d3d12_device_from_ID3D12DXVKInteropDevice(iface);
    return d3d12_device_release(device);
}

extern HRESULT STDMETHODCALLTYPE d3d12_device_QueryInterface(d3d12_device_iface *iface,
        REFIID riid, void **object);

static HRESULT STDMETHODCALLTYPE d3d12_dxvk_interop_device_QueryInterface(d3d12_dxvk_interop_device_iface *iface,
        REFIID iid, void **out)
{
    struct d3d12_device *device = d3d12_device_from_ID3D12DXVKInteropDevice(iface);
    TRACE("iface %p, iid %s, out %p.\n", iface, debugstr_guid(iid), out);
    return d3d12_device_QueryInterface(&device->ID3D12Device_iface, iid, out);
}

static HRESULT STDMETHODCALLTYPE d3d12_dxvk_interop_device_GetDXGIAdapter(d3d12_dxvk_interop_device_iface *iface,
        REFIID iid, void **object)
{
    struct d3d12_device *device = d3d12_device_from_ID3D12DXVKInteropDevice(iface);
    TRACE("iface %p, iid %s, object %p.\n", iface, debugstr_guid(iid), object);
    return IUnknown_QueryInterface(device->parent, iid, object);
}

static HRESULT STDMETHODCALLTYPE d3d12_dxvk_interop_device_GetVulkanHandles(d3d12_dxvk_interop_device_iface *iface,
        VkInstance *vk_instance, VkPhysicalDevice *vk_physical_device, VkDevice *vk_device)
{
    struct d3d12_device *device = d3d12_device_from_ID3D12DXVKInteropDevice(iface);
    TRACE("iface %p, vk_instance %p, vk_physical_device %p, vk_device %p\n", iface, vk_instance, vk_physical_device, vk_device);
    if (!vk_device || !vk_instance || !vk_physical_device)
        return E_INVALIDARG;

    *vk_instance = device->vkd3d_instance->vk_instance;
    *vk_physical_device = device->vk_physical_device;
    *vk_device = device->vk_device;
    return S_OK;
}

static HRESULT STDMETHODCALLTYPE d3d12_dxvk_interop_device_GetInstanceExtensions(d3d12_dxvk_interop_device_iface *iface, UINT *extension_count, const char **extensions)
{
    struct d3d12_device *device = d3d12_device_from_ID3D12DXVKInteropDevice(iface);
    struct vkd3d_instance *instance = device->vkd3d_instance;

    TRACE("iface %p, extension_count %p, extensions %p.\n", iface, extension_count, extensions);

    if (!extension_count || (extensions && (*extension_count < instance->vk_info.extension_count)))
        return E_INVALIDARG;

    *extension_count = instance->vk_info.extension_count;

    if (!extensions)
        return S_OK;

    memcpy(extensions, instance->vk_info.extension_names,
            sizeof(*extensions) * instance->vk_info.extension_count);
    return S_OK;
}

static HRESULT STDMETHODCALLTYPE d3d12_dxvk_interop_device_GetDeviceExtensions(d3d12_dxvk_interop_device_iface *iface, UINT *extension_count, const char **extensions)
{
    struct d3d12_device *device = d3d12_device_from_ID3D12DXVKInteropDevice(iface);

    TRACE("iface %p, extension_count %p, extensions %p.\n", iface, extension_count, extensions);

    if (!extension_count || (extensions && (*extension_count < device->vk_info.extension_count)))
        return E_INVALIDARG;

    *extension_count = device->vk_info.extension_count;

    if (!extensions)
        return S_OK;

    memcpy(extensions, device->vk_info.extension_names,
            sizeof(*extensions) * device->vk_info.extension_count);
    return S_OK;
}

static HRESULT STDMETHODCALLTYPE d3d12_dxvk_interop_device_GetDeviceFeatures(d3d12_dxvk_interop_device_iface *iface, const VkPhysicalDeviceFeatures2 **features)
{
    struct d3d12_device *device = d3d12_device_from_ID3D12DXVKInteropDevice(iface);

    TRACE("iface %p, features %p.\n", iface, features);

    *features = &device->device_info.features2;
    return S_OK;
}

static HRESULT STDMETHODCALLTYPE d3d12_dxvk_interop_device_GetVulkanQueueInfo(d3d12_dxvk_interop_device_iface *iface,
        ID3D12CommandQueue *queue, VkQueue *vk_queue, UINT32 *vk_queue_family)
{
    TRACE("iface %p, queue %p, vk_queue %p, vk_queue_family %p.\n", iface, queue, vk_queue, vk_queue_family);

    if (FAILED(ID3D12CommandQueue_QueryInterface(queue, &IID_ID3D12ExtDummyInterface, (void **)&queue)))
    {
        ERR("no ID3D12ExtDummyInterface.\n");
        return E_FAIL;
    }

    *vk_queue = vkd3d_lock_vk_queue(queue);
    vkd3d_unlock_vk_queue(queue);

    *vk_queue_family = vkd3d_get_vk_queue_family_index(queue);
    ID3D12CommandQueue_Release(queue);
    return S_OK;
}

static void STDMETHODCALLTYPE d3d12_dxvk_interop_device_GetVulkanImageLayout(d3d12_dxvk_interop_device_iface *iface,
        ID3D12Resource *resource, D3D12_RESOURCE_STATES state, VkImageLayout *vk_layout)
{
    struct d3d12_resource *resource_impl = impl_from_ID3D12Resource(resource);

    TRACE("iface %p, resource %p, state %#x.\n", iface, resource, state);

    *vk_layout = vk_image_layout_from_d3d12_resource_state(NULL, resource_impl, state);
}

static HRESULT STDMETHODCALLTYPE d3d12_dxvk_interop_device_GetVulkanResourceInfo1(d3d12_dxvk_interop_device_iface *iface,
        ID3D12Resource *resource, UINT64 *vk_handle, UINT64 *buffer_offset, VkFormat *format)
{
    struct d3d12_resource *resource_impl = impl_from_ID3D12Resource(resource);

    TRACE("iface %p, resource %p, vk_handle %p.\n", iface, resource, vk_handle);

    if (resource_impl->desc.Dimension == D3D12_RESOURCE_DIMENSION_BUFFER)
    {
        *vk_handle = (UINT64)resource_impl->res.vk_buffer;
        *buffer_offset = (UINT64)resource_impl->mem.offset;

        if (format)
            *format = VK_FORMAT_UNDEFINED;
    }
    else
    {
        *vk_handle = (UINT64)resource_impl->res.vk_image;

        if (format)
        {
            if (resource_impl->format)
                *format = resource_impl->format->vk_format;
            else
                *format = VK_FORMAT_UNDEFINED;
        }

        *buffer_offset = 0;
    }

    return S_OK;
}

static HRESULT STDMETHODCALLTYPE d3d12_dxvk_interop_device_GetVulkanResourceInfo(d3d12_dxvk_interop_device_iface *iface,
        ID3D12Resource *resource, UINT64 *vk_handle, UINT64 *buffer_offset)
{
    return d3d12_dxvk_interop_device_GetVulkanResourceInfo1(iface, resource, vk_handle, buffer_offset, NULL);
}

static HRESULT STDMETHODCALLTYPE d3d12_dxvk_interop_device_LockCommandQueue(d3d12_dxvk_interop_device_iface *iface, ID3D12CommandQueue *queue)
{
    struct d3d12_device *device = d3d12_device_from_ID3D12DXVKInteropDevice(iface);

    TRACE("iface %p, queue %p.\n", iface, queue);

    if (FAILED(ID3D12CommandQueue_QueryInterface(queue, &IID_ID3D12ExtDummyInterface, (void **)&queue)))
    {
        ERR("no ID3D12ExtDummyInterface.\n");
        return E_FAIL;
    }

    /* Flushing the transfer queue adds a wait to all other queues, and the
     * acquire operation will drain the queue, ensuring that any pending clear
     * or upload happens before D3D11 submissions on the GPU timeline. */
    vkd3d_memory_transfer_queue_flush(&device->memory_transfers);
    vkd3d_acquire_vk_queue(queue);
    ID3D12CommandQueue_Release(queue);
    return S_OK;
}

static HRESULT STDMETHODCALLTYPE d3d12_dxvk_interop_device_UnlockCommandQueue(d3d12_dxvk_interop_device_iface *iface, ID3D12CommandQueue *queue)
{
    TRACE("iface %p, queue %p.\n", iface, queue);

    if (FAILED(ID3D12CommandQueue_QueryInterface(queue, &IID_ID3D12ExtDummyInterface, (void **)&queue)))
    {
        ERR("no ID3D12ExtDummyInterface.\n");
        return E_FAIL;
    }

    vkd3d_release_vk_queue(queue);
    ID3D12CommandQueue_Release(queue);
    return S_OK;
}

static HRESULT STDMETHODCALLTYPE d3d12_dxvk_interop_device_CreateInteropCommandQueue(d3d12_dxvk_interop_device_iface *iface,
        const D3D12_COMMAND_QUEUE_DESC *desc, uint32_t vk_family_index, ID3D12CommandQueue **command_queue)
{
    struct d3d12_device *device = d3d12_device_from_ID3D12DXVKInteropDevice(iface);
    struct d3d12_command_queue *object;
    HRESULT hr;

    TRACE("iface %p, desc %p, vk_family_index %"PRIu32", command_queue %p.\n",
            iface, desc, vk_family_index, command_queue);

    hr = d3d12_command_queue_create(device, desc, vk_family_index, &object);
    if (FAILED(hr))
        return hr;

    *command_queue = (ID3D12CommandQueue *)&object->ID3D12CommandQueue_iface;

    return S_OK;
}

static HRESULT STDMETHODCALLTYPE d3d12_dxvk_interop_device_CreateInteropCommandAllocator(d3d12_dxvk_interop_device_iface *iface,
        D3D12_COMMAND_LIST_TYPE type, uint32_t vk_family_index, ID3D12CommandAllocator **command_allocator)
{
    struct d3d12_device *device = d3d12_device_from_ID3D12DXVKInteropDevice(iface);
    struct d3d12_command_allocator *object;
    HRESULT hr;

    TRACE("iface %p, type %x, vk_family_index %"PRIu32", command_allocator %p.\n",
            iface, type, vk_family_index, command_allocator);

    hr = d3d12_command_allocator_create(device, type, vk_family_index, &object);
    if (FAILED(hr))
        return hr;

    *command_allocator = (ID3D12CommandAllocator *)&object->ID3D12CommandAllocator_iface;

    return S_OK;
}

static HRESULT STDMETHODCALLTYPE d3d12_dxvk_interop_device_BeginVkCommandBufferInterop(d3d12_dxvk_interop_device_iface *iface,
        ID3D12CommandList *pCmdList, VkCommandBuffer *cmdBuf)
{
    struct d3d12_command_list *cmd_list;
    cmd_list = d3d12_command_list_from_iface(pCmdList);

    if (!cmd_list)
        return E_INVALIDARG;

    if (cmd_list->is_inside_render_pass)
        FIXME("Interop may not work inside a D3D12 render pass.\n");
    if (cmd_list->predication.enabled_on_command_buffer)
        FIXME("Leaking predication across interop barrier. May not work as intended.\n");

    /* Need to assume that any number of action commands can happen. */
    cmd_list->cmd.suspend_resume.block_resume = true;

    d3d12_command_list_decay_tracked_state(cmd_list);
    d3d12_command_list_invalidate_all_state(cmd_list);

    *cmdBuf = cmd_list->cmd.vk_command_buffer;

    return S_OK;
}

static HRESULT STDMETHODCALLTYPE d3d12_dxvk_interop_device_EndVkCommandBufferInterop(d3d12_dxvk_interop_device_iface *iface,
        ID3D12CommandList *pCmdList)
{
    /* Reserved for future VK interop use */
    return S_OK;
}

static HRESULT STDMETHODCALLTYPE d3d12_dxvk_interop_device_LockVulkanQueue(d3d12_dxvk_interop_device_iface *iface, ID3D12CommandQueue *queue)
{
    TRACE("iface %p, queue %p.\n", iface, queue);

    if (FAILED(ID3D12CommandQueue_QueryInterface(queue, &IID_ID3D12ExtDummyInterface, (void **)&queue)))
    {
        ERR("no ID3D12ExtDummyInterface.\n");
        return E_FAIL;
    }

    vkd3d_lock_vk_queue(queue);
    ID3D12CommandQueue_Release(queue);
    return S_OK;
}

static HRESULT STDMETHODCALLTYPE d3d12_dxvk_interop_device_UnlockVulkanQueue(d3d12_dxvk_interop_device_iface *iface, ID3D12CommandQueue *queue)
{
    TRACE("iface %p, queue %p.\n", iface, queue);

    if (FAILED(ID3D12CommandQueue_QueryInterface(queue, &IID_ID3D12ExtDummyInterface, (void **)&queue)))
    {
        ERR("no ID3D12ExtDummyInterface.\n");
        return E_FAIL;
    }

    vkd3d_unlock_vk_queue(queue);
    ID3D12CommandQueue_Release(queue);
    return S_OK;
}

static HRESULT STDMETHODCALLTYPE d3d12_dxvk_interop_device_GetVulkanHeapInfo(d3d12_dxvk_interop_device_iface *iface,
    ID3D12Heap *heap, UINT64 *vk_memory, UINT64 *heap_offset, UINT32 *vk_memory_type)
{
    struct d3d12_device *device = d3d12_device_from_ID3D12DXVKInteropDevice(iface);
    struct d3d12_heap *heap_impl;

    TRACE("iface %p, heap %p, vk_memory %p, heap_offset %p, vk_memory_type %p.\n",
        iface, heap, vk_memory, heap_offset, vk_memory_type);

    if (!heap || !vk_memory || !heap_offset || !vk_memory_type)
        return E_INVALIDARG;

    heap_impl = impl_from_ID3D12Heap(heap);
    if (heap_impl->device != device)
        return E_INVALIDARG;

    if (heap_impl->allocation.device_allocation.vk_memory == VK_NULL_HANDLE)
        return E_FAIL;

    *vk_memory = (UINT64)heap_impl->allocation.device_allocation.vk_memory;
    *heap_offset = (UINT64)heap_impl->allocation.offset;
    *vk_memory_type = heap_impl->allocation.device_allocation.vk_memory_type;
    return S_OK;
}

CONST_VTBL struct ID3D12DXVKInteropDevice3Vtbl d3d12_dxvk_interop_device_vtbl =
{
    /* IUnknown methods */
    d3d12_dxvk_interop_device_QueryInterface,
    d3d12_dxvk_interop_device_AddRef,
    d3d12_dxvk_interop_device_Release,

    /* ID3D12DXVKInteropDevice methods */
    d3d12_dxvk_interop_device_GetDXGIAdapter,
    d3d12_dxvk_interop_device_GetInstanceExtensions,
    d3d12_dxvk_interop_device_GetDeviceExtensions,
    d3d12_dxvk_interop_device_GetDeviceFeatures,
    d3d12_dxvk_interop_device_GetVulkanHandles,
    d3d12_dxvk_interop_device_GetVulkanQueueInfo,
    d3d12_dxvk_interop_device_GetVulkanImageLayout,
    d3d12_dxvk_interop_device_GetVulkanResourceInfo,
    d3d12_dxvk_interop_device_LockCommandQueue,
    d3d12_dxvk_interop_device_UnlockCommandQueue,

    /* ID3D12DXVKInteropDevice1 methods */
    d3d12_dxvk_interop_device_GetVulkanResourceInfo1,
    d3d12_dxvk_interop_device_CreateInteropCommandQueue,
    d3d12_dxvk_interop_device_CreateInteropCommandAllocator,
    d3d12_dxvk_interop_device_BeginVkCommandBufferInterop,
    d3d12_dxvk_interop_device_EndVkCommandBufferInterop,

    /* ID3D12DXVKInteropDevice2 methods */
    d3d12_dxvk_interop_device_LockVulkanQueue,
    d3d12_dxvk_interop_device_UnlockVulkanQueue,

    /* ID3D12DXVKInteropDevice3 methods */
    d3d12_dxvk_interop_device_GetVulkanHeapInfo,
};

void d3d12_device_notify_vk_swapchain_creation(struct d3d12_device *device, struct dxgi_vk_swap_chain *chain)
{
    if (!device->vk_info.NV_low_latency2)
        return;

    spinlock_acquire(&device->low_latency_swapchain_spinlock);

    if (device->swapchain_info.low_latency_swapchain && device->swapchain_info.low_latency_swapchain != chain)
    {
        /* Hard evidence of multiple swapchains being in flight. */
        dxgi_vk_swap_chain_set_latency_sleep_mode(chain, false, false, 0);
        dxgi_vk_swap_chain_decref(device->swapchain_info.low_latency_swapchain);
        WARN("Multiple swapchains are in-flight. LL2 will be disabled until the situation stabilizes.\n");
        device->swapchain_info.low_latency_swapchain = NULL;
    }

    spinlock_release(&device->low_latency_swapchain_spinlock);
}

void d3d12_device_register_low_latency_swapchain(struct d3d12_device *device, struct dxgi_vk_swap_chain *chain)
{
    if (!device->vk_info.NV_low_latency2)
        return;

    spinlock_acquire(&device->low_latency_swapchain_spinlock);

    device->swapchain_info.dxgi_swapchain_count++;

    if (device->swapchain_info.dxgi_swapchain_count == 1 && !device->swapchain_info.low_latency_swapchain)
    {
        dxgi_vk_swap_chain_incref(chain);
        device->swapchain_info.low_latency_swapchain = chain;
        dxgi_vk_swap_chain_set_latency_sleep_mode(chain, device->swapchain_info.mode,
                device->swapchain_info.boost, device->swapchain_info.minimum_us);
    }

    /* Defer the demotion of the existing low-latency swapchain.
     * Supposedly, there are applications that create a second swapchain, but never actually present anything to it
     * before destroying it.
     * It will never create a Vulkan swapchain and will not conflict with LL2.
     * We can defer the demotion until we have evidence later. */

    spinlock_release(&device->low_latency_swapchain_spinlock);
}

void d3d12_device_remove_low_latency_swapchain(struct d3d12_device *device, struct dxgi_vk_swap_chain *chain)
{
    if (!device->vk_info.NV_low_latency2)
        return;

    spinlock_acquire(&device->low_latency_swapchain_spinlock);

    assert(device->swapchain_info.dxgi_swapchain_count);
    device->swapchain_info.dxgi_swapchain_count--;

    if (device->swapchain_info.low_latency_swapchain == chain)
    {
        dxgi_vk_swap_chain_decref(chain);
        device->swapchain_info.low_latency_swapchain = NULL;
    }

    spinlock_release(&device->low_latency_swapchain_spinlock);
}

static inline struct d3d12_device *d3d12_device_from_ID3DLowLatencyDevice(d3d_low_latency_device_iface *iface)
{
    return CONTAINING_RECORD(iface, struct d3d12_device, ID3DLowLatencyDevice_iface);
}

ULONG STDMETHODCALLTYPE d3d12_low_latency_device_AddRef(d3d_low_latency_device_iface *iface)
{
    struct d3d12_device *device = d3d12_device_from_ID3DLowLatencyDevice(iface);
    return d3d12_device_add_ref(device);
}

static ULONG STDMETHODCALLTYPE d3d12_low_latency_device_Release(d3d_low_latency_device_iface *iface)
{
    struct d3d12_device *device = d3d12_device_from_ID3DLowLatencyDevice(iface);
    return d3d12_device_release(device);
}

extern HRESULT STDMETHODCALLTYPE d3d12_device_QueryInterface(d3d12_device_iface *iface,
        REFIID riid, void **object);

static HRESULT STDMETHODCALLTYPE d3d12_low_latency_device_QueryInterface(d3d_low_latency_device_iface *iface,
        REFIID iid, void **out)
{
    struct d3d12_device *device = d3d12_device_from_ID3DLowLatencyDevice(iface);
    TRACE("iface %p, iid %s, out %p.\n", iface, debugstr_guid(iid), out);
    return d3d12_device_QueryInterface(&device->ID3D12Device_iface, iid, out);
}

static BOOL STDMETHODCALLTYPE d3d12_low_latency_device_SupportsLowLatency(d3d_low_latency_device_iface *iface)
{
    struct d3d12_device *device;

    device = d3d12_device_from_ID3DLowLatencyDevice(iface);

    return device->vk_info.NV_low_latency2;
}

static HRESULT STDMETHODCALLTYPE d3d12_low_latency_device_LatencySleep(d3d_low_latency_device_iface *iface)
{
    struct dxgi_vk_swap_chain *low_latency_swapchain;
    struct d3d12_device *device;

    device = d3d12_device_from_ID3DLowLatencyDevice(iface);

    if (!device->vk_info.NV_low_latency2)
        return E_NOTIMPL;

    spinlock_acquire(&device->low_latency_swapchain_spinlock);
    if ((low_latency_swapchain = device->swapchain_info.low_latency_swapchain))
        dxgi_vk_swap_chain_incref(low_latency_swapchain);
    spinlock_release(&device->low_latency_swapchain_spinlock);

    if (low_latency_swapchain)
    {
        dxgi_vk_swap_chain_latency_sleep(low_latency_swapchain);
        dxgi_vk_swap_chain_decref(low_latency_swapchain);
    }

    return S_OK;
}

static HRESULT STDMETHODCALLTYPE d3d12_low_latency_device_SetLatencySleepMode(d3d_low_latency_device_iface *iface,
        BOOL low_latency_mode, BOOL low_latency_boost,
        UINT32 minimum_interval_us)
{
    struct dxgi_vk_swap_chain *low_latency_swapchain;
    struct d3d12_device *device;

    device = d3d12_device_from_ID3DLowLatencyDevice(iface);

    if (!device->vk_info.NV_low_latency2)
        return E_NOTIMPL;

    spinlock_acquire(&device->low_latency_swapchain_spinlock);
    device->swapchain_info.mode = low_latency_mode;
    device->swapchain_info.boost = low_latency_boost;
    device->swapchain_info.minimum_us = minimum_interval_us;
    if ((low_latency_swapchain = device->swapchain_info.low_latency_swapchain))
        dxgi_vk_swap_chain_incref(low_latency_swapchain);
    spinlock_release(&device->low_latency_swapchain_spinlock);

    if (low_latency_swapchain)
    {
        dxgi_vk_swap_chain_set_latency_sleep_mode(low_latency_swapchain, low_latency_mode, low_latency_boost, minimum_interval_us);
        dxgi_vk_swap_chain_decref(low_latency_swapchain);
    }

    return S_OK;
}

static HRESULT STDMETHODCALLTYPE d3d12_low_latency_device_SetLatencyMarker(d3d_low_latency_device_iface *iface, UINT64 frameID, UINT32 markerType)
{
    struct dxgi_vk_swap_chain *low_latency_swapchain;
    VkLatencyMarkerNV vk_marker;
    struct d3d12_device *device;

    device = d3d12_device_from_ID3DLowLatencyDevice(iface);
    vk_marker = (VkLatencyMarkerNV)markerType;

    if (!device->vk_info.NV_low_latency2)
        return E_NOTIMPL;

    if (frameID == 0)
    {
        WARN("FrameID is 0. Not a valid present ID.\n");
        return S_OK;
    }

    switch (vk_marker)
    {
        case VK_LATENCY_MARKER_SIMULATION_START_NV:
        {
            struct vkd3d_device_frame_markers *markers = &device->frame_markers;
            spinlock_acquire(&device->low_latency_swapchain_spinlock);
            markers->recent_sim_starts[markers->recent_sim_starts_index] = frameID;
            markers->recent_sim_starts_index = (markers->recent_sim_starts_index + 1) % VKD3D_RECENT_SIM_STARTS_COUNT;
            spinlock_release(&device->low_latency_swapchain_spinlock);
            break;
        }
        case VK_LATENCY_MARKER_PRESENT_END_NV:
            spinlock_acquire(&device->low_latency_swapchain_spinlock);
            device->frame_markers.present_end = frameID;
            device->frame_markers.new_frame = true;
            spinlock_release(&device->low_latency_swapchain_spinlock);
            break;
        case VK_LATENCY_MARKER_PRESENT_START_NV:
            if (frameID < device->frame_markers.present)
            {
                WARN("PRESENT_START_NV is non-monotonic %"PRIu64" < %"PRIu64".\n",
                        frameID, device->frame_markers.present);
            }
            vkd3d_atomic_uint64_store_explicit(
                    &device->frame_markers.present, frameID, vkd3d_memory_order_release);
            break;
        case VK_LATENCY_MARKER_OUT_OF_BAND_RENDERSUBMIT_START_NV:
            vkd3d_atomic_uint64_store_explicit(
                    &device->frame_markers.out_of_band_render, frameID, vkd3d_memory_order_release);
            break;
        default:
            break;
    }

    spinlock_acquire(&device->low_latency_swapchain_spinlock);
    if ((low_latency_swapchain = device->swapchain_info.low_latency_swapchain))
        dxgi_vk_swap_chain_incref(low_latency_swapchain);
    spinlock_release(&device->low_latency_swapchain_spinlock);

    if (low_latency_swapchain)
    {
        dxgi_vk_swap_chain_set_latency_marker(low_latency_swapchain, frameID, vk_marker, true);
        dxgi_vk_swap_chain_decref(low_latency_swapchain);
    }

    return S_OK;
}

static HRESULT STDMETHODCALLTYPE d3d12_low_latency_device_GetLatencyInfo(d3d_low_latency_device_iface *iface, D3D12_LATENCY_RESULTS *latency_results)
{
    struct dxgi_vk_swap_chain *low_latency_swapchain;
    struct d3d12_device *device;

    device = d3d12_device_from_ID3DLowLatencyDevice(iface);

    if (!device->vk_info.NV_low_latency2)
        return E_NOTIMPL;

    spinlock_acquire(&device->low_latency_swapchain_spinlock);
    if ((low_latency_swapchain = device->swapchain_info.low_latency_swapchain))
        dxgi_vk_swap_chain_incref(low_latency_swapchain);
    spinlock_release(&device->low_latency_swapchain_spinlock);

    if (low_latency_swapchain)
    {
        dxgi_vk_swap_chain_get_latency_info(low_latency_swapchain, latency_results);
        dxgi_vk_swap_chain_decref(low_latency_swapchain);
    }

    return S_OK;
}

CONST_VTBL struct ID3DLowLatencyDeviceVtbl d3d_low_latency_device_vtbl =
{
    /* IUnknown methods */
    d3d12_low_latency_device_QueryInterface,
    d3d12_low_latency_device_AddRef,
    d3d12_low_latency_device_Release,

    /* ID3DLowLatencyDevice methods */
    d3d12_low_latency_device_SupportsLowLatency,
    d3d12_low_latency_device_LatencySleep,
    d3d12_low_latency_device_SetLatencySleepMode,
    d3d12_low_latency_device_SetLatencyMarker,
    d3d12_low_latency_device_GetLatencyInfo
};

static inline struct d3d12_device *d3d12_device_from_IAmdExtAntiLag(IAmdExtAntiLagApi *iface)
{
    return CONTAINING_RECORD(iface, struct d3d12_device, IAmdExtAntiLagApi_iface);
}

ULONG STDMETHODCALLTYPE d3d12_amd_ext_anti_lag_AddRef(IAmdExtAntiLagApi *iface)
{
    struct d3d12_device *device = d3d12_device_from_IAmdExtAntiLag(iface);
    TRACE("iface %p", iface);
    return d3d12_device_add_ref(device);
}

static ULONG STDMETHODCALLTYPE d3d12_amd_ext_anti_lag_Release(IAmdExtAntiLagApi *iface)
{
    struct d3d12_device *device = d3d12_device_from_IAmdExtAntiLag(iface);
    TRACE("iface %p", iface);
    return d3d12_device_release(device);
}

static HRESULT STDMETHODCALLTYPE d3d12_amd_ext_anti_lag_QueryInterface(IAmdExtAntiLagApi *iface,
        REFIID iid, void **out)
{
    struct d3d12_device *device = d3d12_device_from_IAmdExtAntiLag(iface);
    TRACE("iface %p, iid %s, out %p.\n", iface, debugstr_guid(iid), out);
    return d3d12_device_QueryInterface(&device->ID3D12Device_iface, iid, out);
}

static HRESULT STDMETHODCALLTYPE d3d12_amd_ext_anti_lag_UpdateAntiLagState(
        IAmdExtAntiLagApi *iface, void *pData)
{
    struct d3d12_device *device = d3d12_device_from_IAmdExtAntiLag(iface);
    const struct vkd3d_vk_device_procs *vk_procs = &device->vk_procs;
    const struct AmdAntiLagAPIData_v1 *v1 = pData;
    const struct AmdAntiLagAPIData_v2 *v2 = pData;

    /* Don't try to use LL2 and AMD anti-lag at the same time. */
    if (!device->device_info.anti_lag_amd.antiLag || device->vk_info.NV_low_latency2)
        return S_OK;

    /* The assumption is that this function cannot be called concurrently,
     * but it probably can be called concurrently with e.g. Present and ExecuteCommandList. */

    if (!pData)
    {
        struct vkd3d_queue_timeline_trace_cookie cookie = { 0 };
        VkAntiLagDataAMD anti_lag;

        memset(&anti_lag, 0, sizeof(anti_lag));
        anti_lag.sType = VK_STRUCTURE_TYPE_ANTI_LAG_DATA_AMD;
        anti_lag.mode = device->swapchain_info.mode ? VK_ANTI_LAG_MODE_ON_AMD : VK_ANTI_LAG_MODE_OFF_AMD;
        anti_lag.maxFPS = device->swapchain_info.max_fps;

        /* The AntiLag API has no useful present IDs we can correlate with.
         * The Vulkan API allows not passing down presentation information at all, which
         * means that in this mode we give the driver the full responsibility of figuring out how to
         * deal with frame boundaries. The expectation is that the driver can use vkQueuePresentKHR as
         * a split point. Any submits happening after QueuePresentKHR would be assumed to belong to a future frame. */

        /* There is no robust way to keep track of frame indices ourselves, since application can do threaded presents
         * and end up with INPUT -> INPUT -> PRESENT -> PRESENT patterns which just break.
         * Even if we try to keep track of this, INPUT and PRESENT can get out of sync, which is terrible too. */

        if (device->swapchain_info.mode)
            cookie = vkd3d_queue_timeline_trace_register_low_latency_sleep(&device->queue_timeline_trace, 0);
        VK_CALL(vkAntiLagUpdateAMD(device->vk_device, &anti_lag));
        if (device->swapchain_info.mode)
            vkd3d_queue_timeline_trace_complete_low_latency_sleep(&device->queue_timeline_trace, cookie);
    }
    else if (v1->uiVersion == 1)
    {
        /* Mode setting for v1. */
        if (v1->uiSize != sizeof(*v1))
        {
            ERR("Invalid size for API structure.\n");
            return E_INVALIDARG;
        }

        spinlock_acquire(&device->low_latency_swapchain_spinlock);
        device->swapchain_info.max_fps = v1->maxFPS;
        device->swapchain_info.mode = v1->eMode == 1;
        spinlock_release(&device->low_latency_swapchain_spinlock);
        TRACE("AntiLag v1 config: MaxFPS = %u, Enabled = %u\n",
                device->swapchain_info.max_fps, device->swapchain_info.mode);
    }
    else if (v2->uiVersion == 2)
    {
        /* Mode setting for v2. */
        if (v2->uiSize != sizeof(*v2))
        {
            ERR("Invalid size for API structure.\n");
            return E_INVALIDARG;
        }

        /* This structure only seems to flag certain things, and does not modify the mode?
         * There isn't much we can do with this struct right now I think other than logging ... */
        TRACE("AntiLag v2 config: Frame = %"PRIu64", signalFgFrameType = %u, isInterpolatedFrame = %u, signalGetUserInputIdx = %u, signalEndOfFrameIdx = %u\n",
                v2->iiFrameIdx,
                v2->flags.signalFgFrameType, v2->flags.isInterpolatedFrame,
                v2->flags.signalGetUserInputIdx, v2->flags.signalEndOfFrameIdx);
    }
    else
    {
        ERR("Invalid uiVersion %u.\n", v1->uiVersion);
        return E_INVALIDARG;
    }

    return S_OK;
}

CONST_VTBL struct IAmdExtAntiLagApiVtbl d3d_amd_ext_anti_lag_vtbl =
{
    /* IUnknown methods */
    d3d12_amd_ext_anti_lag_QueryInterface,
    d3d12_amd_ext_anti_lag_AddRef,
    d3d12_amd_ext_anti_lag_Release,

    /* IAmdExtAntiLag methods */
    d3d12_amd_ext_anti_lag_UpdateAntiLagState
};
